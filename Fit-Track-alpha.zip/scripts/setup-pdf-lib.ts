// This script ensures jsPDF is available as a dynamic import
// No build-time setup required - uses dynamic import for client-side PDF generation
console.log("PDF library setup ready - jsPDF will be dynamically imported when needed")
